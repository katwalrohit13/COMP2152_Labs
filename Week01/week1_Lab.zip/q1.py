# Sample Coding Questions 01 Week 01
# Suryadev singh
# Date: 2026-01-18

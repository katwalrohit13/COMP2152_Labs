# Sample Coding Questions 01 Week 01
# Rohit Kumar
# Date: 2026-01-13
